var bananaImage, obstacleImage, obstcaleGroup, background, score;

function preload(){
backImage = loadImage = ("jungle.png");
player_running = loadAnimation = ("
  
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}